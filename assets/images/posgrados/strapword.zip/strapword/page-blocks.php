<?php
  // Template Name: ACF Blocks
  get_header(); 
  strapword_mainbody_before();
?>

<main id="site-main">

<?php the_content(); ?>

</main>

<?php 
  strapword_mainbody_after();
  get_footer(); 
?>