<?php

/* add_filter( 'block_categories_all' , function( $categories ) {

    // Adding a new category.
	$categories[] = array(
		'slug'  => 'landing-blocks',
		'title' => 'Bloques landing'
	);

	return $categories;
} ); */


// Adding a new (custom) block category and show that category at the top
add_filter( 'block_categories_all', 'example_block_category', 10, 2);
function example_block_category( $categories, $post ) {
	
	array_unshift( $categories, array(
		'slug'  => 'landing-blocks',
		'title' => 'Bloques landing'
	) );

	return $categories;
}

function strapword_register_acf_blocks() {

    //register_block_type( __DIR__ . '/../blocks/quienes-somos' );
    //register_block_type( __DIR__ . '/../blocks/portfolio' );
    register_block_type( __DIR__ . '/../blocks/certificacion' );
    register_block_type( __DIR__ . '/../blocks/desplegable' );
    register_block_type( __DIR__ . '/../blocks/contacto' );
    register_block_type( __DIR__ . '/../blocks/descripcion' );
    register_block_type( __DIR__ . '/../blocks/contenido' );
    register_block_type( __DIR__ . '/../blocks/diploma' );
    register_block_type( __DIR__ . '/../blocks/testimonios' );
    register_block_type( __DIR__ . '/../blocks/datos-generales' );
    register_block_type( __DIR__ . '/../blocks/banner-hero' );
    register_block_type( __DIR__ . '/../blocks/grid-landing' );

}

add_action( 'init', 'strapword_register_acf_blocks' );