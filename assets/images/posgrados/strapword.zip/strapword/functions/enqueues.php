<?php
/*
 * Enqueues
 */

if ( ! function_exists('strapword_enqueues') ) {
	function strapword_enqueues() {

        wp_register_style('animate', VENDOR_ASSETS_URL . 'animate.css/animate.min.css', false, '4.1.1',);
        wp_enqueue_style('animate');

		// Scripts
		wp_register_script('bootstrap5', VENDOR_ASSETS_URL . 'bootstrap/bootstrap.min.js', false, '5.3.3', array( 'strategy' => 'defer'));
		wp_enqueue_script('bootstrap5');

		wp_register_script('default', JS_TEMPLATES_ASSETS_URL . 'default.min.js', false, null, true);
		wp_enqueue_script('default');

        wp_register_script('landings', JS_TEMPLATES_ASSETS_URL . 'landings.min.js', false, null, true);
        wp_enqueue_script('landings');

        wp_register_script('swiperJS', VENDOR_ASSETS_URL . 'swiper-js/swiper-bundle.min.js', false, '11.1.0', array( 'strategy' => 'defer'));
        wp_enqueue_script('swiperJS');

        wp_register_script('scrolla', VENDOR_ASSETS_URL . 'scrolla/jquery.scrolla.min.js', array('jquery'), '0.0.3', array( 'strategy' => 'defer'));
        wp_enqueue_script('scrolla');

		if (is_singular() && comments_open() && get_option('thread_comments')) {
			wp_enqueue_script('comment-reply');
		}
	}
}
add_action('wp_enqueue_scripts', 'strapword_enqueues', 100);

function strapword_enqueues_styles() {

    wp_register_style('bootstrap', VENDOR_CSS_ASSETS_URL . '/bootstrap/bootstrap.min.css', false, '5.3.3' ,  null);
    wp_enqueue_style('bootstrap');

    wp_register_style('theme', CSS_ASSETS_URL . '/theme/base.min.css', false, false ,  null);
    wp_enqueue_style('theme');

    wp_register_style('swiperJS', VENDOR_ASSETS_URL .'swiper-js/swiper-bundle.min.css', false, '11.1.0', null);
    wp_enqueue_style('swiperJS');
 }
 add_action( 'enqueue_block_assets', 'strapword_enqueues_styles' );