<?php
define( 'ASSETS_URL', trailingslashit( get_stylesheet_directory_uri () ) . 'assets/' );
define( 'VENDOR_ASSETS_URL', ASSETS_URL . 'vendor/' );
define( 'JS_ASSETS_URL', ASSETS_URL . 'js/dist/' );
define( 'JS_TEMPLATES_ASSETS_URL', JS_ASSETS_URL . 'templates/');
define( 'CSS_ASSETS_URL', ASSETS_URL . 'css/' );
define( 'VENDOR_CSS_ASSETS_URL', ASSETS_URL . 'css/vendors-extensions/' );
define( 'IMG_ASSETS_URL', ASSETS_URL . 'images/' );