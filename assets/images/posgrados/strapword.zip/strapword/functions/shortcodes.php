<?php


function home_slider_shortcode() {
    ob_start();
    ?>

    <section>
        <div class="container-fluid">
            <div class="row position-relative">
                <div class="swiper swiper-home px-0">
                    <div class="swiper-wrapper">
                        <?php 
                        if ( have_rows( 'opt_slider', 'option' ) ) {
                            while ( have_rows( 'opt_slider', 'option' ) ) {
                                the_row();
                                if ( have_rows('opt_slider_imagenes', 'option')) {
                                    while ( have_rows( 'opt_slider_imagenes', 'option' ) ) {
                                        the_row();
                                        $sliderImgDesktop = get_sub_field( 'opt_slider_image_desktop' );
                                        if ($sliderImgDesktop) {
                                            $sliderImgDesktopUrl = $sliderImgDesktop['url'];
                                            $sliderImgDesktopAlt = $sliderImgDesktop['alt'];
                                        }
                                        $sliderImgMobile = get_sub_field( 'opt_slider_image_mobile' );
                                        if ($sliderImgMobile) {
                                            $sliderImgMobileUrl = $sliderImgMobile['url'];
                                        }
                                    }
                                }
                                if ( have_rows('opt_slider_textos', 'option')) {
                                    while ( have_rows( 'opt_slider_textos', 'option' ) ) {
                                        the_row();
                                        $sliderTitulo = get_sub_field( 'opt_slider_titulo' );
                                        $sliderSubtitulo = get_sub_field( 'opt_slider_subtitulo' );
                                        $sliderUrl = get_sub_field( 'opt_slider_enlace' );
                                        if( ! empty($sliderUrl) ) {
                                            $sliderTxtBtn = get_sub_field( 'opt_slider_texto_btn' );
                                        }
                                    }
                                }

                            
                                $sliderOverlay = '';
                                if ( $sliderTitulo || $sliderSubtitulo ) { $sliderOverlay = ' overlay-5'; }
                            ?>

                                <div class="swiper-slide <?= $sliderOverlay; ?>" >

                                    <?php if ( $sliderUrl ) { ?>
                                            <?php if ( $sliderImgDesktop && $sliderImgMobile ) { ?>
                                                <picture>
                                                    <source srcset="<?= esc_url($sliderImgDesktopUrl); ?>" media="(min-width: 768px)">
                                                    <img src="<?= esc_url($sliderImgMobileUrl); ?>" alt="<?= esc_attr($sliderImgDesktopAlt); ?>" class="img-fluid" loading="lazy">
                                                </picture>    
                                            <?php } else { ?>
                                                <img src="<?= get_template_directory_uri(); ?>/assets/images/placeholder.webp" alt="<?php bloginfo( 'name' ); ?>" class="img-fluid" loading="lazy">
                                            <?php } ?>

                                        <div class="container-fluid swiper-caption py-4" >
                                            <div class="row justify-content-center animate" data-animate="fadeIn" data-duration="1s" data-delay=".3s">
                                                <div class="text-white text-center py-4">

                                                    <h2><?= $sliderTitulo; ?></h2>

                                                    <p class="fs-5 text-break"><?= $sliderSubtitulo; ?></p>

                                                    <?php if ( ! empty($sliderUrl) ) { ?>
                                                    <a target="_self" href="<?= $sliderUrl; ?>" class="btn btn-primary mx-auto"><?= $sliderTxtBtn; ?></a>
                                                    <?php } ?>

                                                </div>
                                            </div>
                                        </div> 
                                    <?php } else { ?>      
                                        <?php if ( $sliderImgDesktop && $sliderImgMobile ) { ?>
                                            <picture>
                                                <source srcset="<?= esc_url($sliderImgDesktopUrl); ?>" media="(min-width: 768px)">
                                                <img src="<?= esc_url($sliderImgMobileUrl); ?>" alt="<?= esc_attr($sliderImgDesktopAlt); ?>" class="img-fluid" loading="lazy">
                                            </picture>    
                                            <?php } else { ?>
                                            <img src="<?= get_template_directory_uri(); ?>/assets/images/placeholder.webp" alt="<?php bloginfo( 'name' ); ?>" class="img-fluid" loading="lazy">
                                            <?php } ?>   
                                            
                                            
                                        <div class="container swiper-caption py-4" >
                                            <div class="row justify-content-center animate" data-animate="fadeIn" data-duration="1s" data-delay=".3s">
                                                <div class="text-white text-center py-4">

                                                    <h2><?= $sliderTitulo; ?></h2>

                                                    <p class="fs-5 text-break"><?= $sliderSubtitulo; ?></p>

                                                </div>
                                            </div>
                                        </div> 
                                    <?php } ?>

                                </div>
                            <?php   
                            } 
                        } else { ?>            
                            <div class="swiper-slide">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/placeholder.webp" alt="<?php bloginfo( 'name' ); ?>" class="img-fluid" loading="lazy">
                            </div>
                        <?php } ?>
                    </div>

                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('home_slider', 'home_slider_shortcode');

