<?php

add_action( 'wp_ajax_load_portfolio_data', 'load_portfolio_data' );
add_action( 'wp_ajax_nopriv_load_portfolio_data', 'load_portfolio_data' );

function load_portfolio_data() {
    $post_id = $_POST['post_id'];
    $portfolio_descripcion = get_field('portfolio_descripcion', $post_id);
    $portfolio_imagen = get_field('portfolio_imagen', $post_id);
    $title = get_the_title($post_id);
    
    $data = array(
        'descripcion' => $portfolio_descripcion,
        'imagen' => $portfolio_imagen,
        'title' => $title
    );

    echo json_encode($data);
    die();
}
