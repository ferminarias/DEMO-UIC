<?php


/* ======================================= */
/*                  Footer                 */
/* ======================================= */

/* ----------- WhatsApp button ----------- */

if ( have_rows( 'opt_whatsapp', 'option' ) ) {
    while ( have_rows( 'opt_whatsapp', 'option' ) ) {
        the_row();
        
        $whatsappButton = get_sub_field( 'opt_whatsapp_on' );

        if ( $whatsappButton ) {
            $whatsappNumber = get_sub_field( 'opt_whatsapp_numero' );
            $whatsappText = get_sub_field( 'opt_whatsapp_texto' );
        }
    } 
}

$gotopButton = get_field( 'opt_btn_go_to_top', 'option' );


