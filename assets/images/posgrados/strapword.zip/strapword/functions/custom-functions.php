<?php

/* ======================================= */
/*                 Load SVG                */
/* ======================================= */

function load_svg( $filename , bool $icon = true) {

    if (empty($filename)) {
        return esc_html__('Ingresar nombre o url del svg', 'strapword');
    }

    $file_path = $icon ? get_stylesheet_directory() . '/assets/images/icons/' . $filename . '.svg' : $filename;

    if ( file_exists( $file_path ) ) {
        return escape_svg( file_get_contents( $file_path ) );
    }

    return esc_html__('Error con el archivo', 'strapword');
}

/* ======================================= */
/*                Filtro SVG               */
/* ======================================= */

function escape_svg($svg) {
    wp_kses($svg, array(
        'svg' => array(
            'xmlns' => array(),
            'width' => array(),
            'height' => array(),
            'viewbox' => array(),
            'fill' => array(),
            'class' => true,
            'aria-hidden' => true,
            'aria-labelledby' => true,
            'role' => true,
        ),
        'path' => array(
            'd' => true,
            'fill' => true,
            'fill-rule' => true,
            'clip-rule' => true,
        ),
        'g' => array(
            'fill' => true,
        ),
        'title' => array(
            'title' => true,
        ),
    )
    );

    return $svg;
}

/* ======================================= */
/*             Custom Code ACF             */
/* ======================================= */

function add_custom_code() {
    if (have_rows( 'opt_codigos', 'option' )) {
        while (have_rows( 'opt_codigos', 'option' )) {
            the_row();
            $text = get_sub_field('opt_codigos_contenido');
            $option = get_sub_field('opt_codigos_contenido_ubicacion');
            
            switch ($option) {
                case 'head':
                    add_action('wp_head', function() use ($text) {
                        echo $text;
                    });
                    break;
                case 'body-start':
                    add_action('wp_body_open', function() use ($text) {
                        echo $text;
                    });
                    break;
                case 'body-end':
                    add_action('wp_footer', function() use ($text) {
                        echo $text;
                    });
                    break;
            }
        }
    }
}
add_action('wp', 'add_custom_code');