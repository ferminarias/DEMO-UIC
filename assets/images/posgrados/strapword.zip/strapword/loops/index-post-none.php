<?php
/*
 * Index Post None
 * E.g. for when you have created a category but there are no posts yet.
 */
?>
