<div id="content" role="main" class="container py-5">
  <h1>
      <i class="bi bi-exclamation-triangle"></i> <?php _e('Error', 'strapword'); ?> 404
  </h1>
  <p class="mt-4"><?php _e('Sorry, we can&rsquo;t find what you were looking for.', 'strapword'); ?></p>
</div><!-- /#content -->