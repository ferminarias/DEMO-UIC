<?php
  // Template Name: ACF Blocks Canvas
  get_header('canvas'); 
  strapword_mainbody_before();
?>

<main id="site-main">

<?php the_content(); ?>

</main>

<?php 
  strapword_mainbody_after();
  get_footer('canvas'); 
?>