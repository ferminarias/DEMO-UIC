<!DOCTYPE html>
<html class="no-js" <?php language_attributes(); ?>>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <?php wp_head(); ?>
</head>

<body id="top" <?php body_class('bg-light'); ?>>

<?php wp_body_open(); ?>

<a class="visually-hidden-focusable d-inline-block p-1" href="#site-main">Skip to main content</a>

<?php strapword_navbar_before();?>
    <header id="navbar-wrapper">
        <nav id="site-navbar" class="navbar navbar-expand-md navbar-light ">
            <div class="container-xxl">

                <?php strapword_navbar_brand();?>

                <button class="navbar-toggler" type="button" aria-label="menú" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                    <?php echo load_svg('list'); ?>
                </button>

                <div class="offcanvas offcanvas-end offcanvas-light" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title" id="offcanvasNavbarLabel"></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body d-flex flex-column flex-md-row align-content-center align-items-md-center  justify-content-between justify-content-md-end">

                <div class="offcanvas-content">
                    
                <?php if ( get_field( 'opt_logo_white', 'option' ) ) { ?>
                    <img src="<?php the_field( 'opt_logo_white', 'option' ); ?>" class="logo-offcanvas" />
                <?php } ?>
                <?php
                    wp_nav_menu( array(
                    'theme_location'  => 'navbar',
                    'container'       => false,
                    'menu_class'      => '',
                    'fallback_cb'     => '__return_false',
                    'items_wrap'      => '<ul id="%1$s" class="navbar-nav ms-0 ms-md-auto %2$s">%3$s</ul>',
                    'depth'           => 2,
                    'walker'          => new strapword_walker_nav_menu()
                    ) );
                ?>

                </div>
                <?php //strapword_navbar_search();?>
                
            <?php if ( have_rows( 'opt_redes_sociales', 'option' ) ) { ?>
                <ul id="menu-redes" class="list-inline text-center mb-0">

                <?php while ( have_rows( 'opt_redes_sociales', 'option' ) ) {
                    the_row(); ?>
                    <li class="list-inline-item">
                        <a class="nav-link mb-0 icon-foward" target="_blank" aria-label="<?php the_sub_field( 'opt_redes_sociales_nombre' ); ?>" href="<?php the_sub_field( 'opt_redes_sociales_enlace' ); ?>"><i class="<?php the_sub_field( 'opt_redes_sociales_icono' ); ?>"></i></a>
                    </li>
                <?php } ?>

                </ul>

            <?php } ?>
                </div>

            </div>
        </nav>
    </header>
  
<?php strapword_navbar_after();?>
