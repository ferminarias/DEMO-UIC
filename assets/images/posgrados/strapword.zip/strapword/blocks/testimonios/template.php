<?php
/**
 * Block template file: template.php
 *
 * Testimonios Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

$diploma_ids = get_field( 'block_acreditacion_diploma' );

 $anchor = '';
 if ( ! empty( $block['anchor'] ) ) {
     $anchor = 'id=' . esc_attr( $block['anchor'] ) . ' ';
 }
 

$class_name = 'testimonios';
if ( ! empty( $block['className'] ) ) {
    $class_name .= ' ' . $block['className'];
} 

$background_color = '';
if ( !empty($block['backgroundColor']) ) {
    $background_color = 'style="background-color: var(--wp--preset--color--' . esc_attr($block['backgroundColor']) . ');"';
} else if (!empty($block['style']['color']['background'])) {
    $background_color = 'style="background-color: ' . esc_attr($block['style']['color']['background']) . ';"';
} 

$testimonio = [];

if ( have_rows( 'block_testimonios' ) ) {
    while ( have_rows( 'block_testimonios' ) ) {
        the_row(); 
        $testimonio[] = [
            'text' => get_sub_field( 'block_testimonio_text' ),
            'name' => get_sub_field( 'block_testimonio_name' ),
            'valoration' => get_sub_field( 'block_testimonio_valoration' ),
        ];
    }
}

?>

<section <?php echo esc_attr( $anchor ); ?>class="pt-4 <?php echo esc_attr( $class_name ); ?>" >

<div class="container-fluid">
    <div class="row">
        <h2 class="p-testimonios">Lo que nuestros alumnos opinan</h2>
        
        <?php if ( !empty($testimonio) ) { ?>
            <div <?php echo $background_color; ?> class="p-testimonios">
                <div class="swiper swiper-testimonios">
                    <div class="swiper-wrapper">
                    <?php foreach( $testimonio as $item ) { ?>
                        <div class="swiper-slide">
                            <div class="item">
                                <span class="text animate" data-animate="fadeInUp" data-duration="1s" data-delay=".3s" ><?php echo $item['text']; ?></span>
                                <div class="author">
                                    <span class="name animate" data-animate="fadeInUp" data-duration="1s" data-delay=".3s" ><?php echo $item['name']; ?></span>
                                    <?php if( !empty( $item['valoration'] )) { ?>
                                    <img src="<?php echo wp_get_attachment_image_url( $item['valoration'] ); ?>" alt="">
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
            <?php } ?>

        </div>
    </div>

</section>

