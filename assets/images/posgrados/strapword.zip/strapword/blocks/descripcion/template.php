<?php
/**
 * Block template file: template.php
 *
 * Descripción Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

 $description = get_field('block_description_content');

 $anchor = '';
 if ( ! empty( $block['anchor'] ) ) {
     $anchor = 'id=' . esc_attr( $block['anchor'] ) . ' ';
 }
 

$class_name = 'description';
if ( ! empty( $block['className'] ) ) {
    $class_name .= ' ' . $block['className'];
} ?>

<section <?= esc_attr( $anchor ); ?>class="<?php echo esc_attr( $class_name ); ?>">
    <div class="container p-0">
        <div class="row">
            <div class="col">
            <?php if( !empty($description) ) { ?>
            <div class="description animate" data-animate="fadeIn" data-duration="1s" data-delay=".3s" ><?php echo $description; ?></div>
            <?php }  ?>
            </div>
        </div>
    </div>
</section>
