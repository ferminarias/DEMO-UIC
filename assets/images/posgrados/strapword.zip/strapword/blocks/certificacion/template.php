<?php
/**
 * Block template file: template.php
 *
 * Certificación Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

 $title = get_field('block_certificacion_title');
 $uni = get_field('block_certificacion_uni');
 $logo = get_field('block_certificacion_logo');
 $description = get_field('block_certificacion_description');

 $anchor = '';
 if ( ! empty( $block['anchor'] ) ) {
     $anchor = 'id=' . esc_attr( $block['anchor'] ) . ' ';
 }
 

$class_name = 'certificacion';
if ( ! empty( $block['className'] ) ) {
    $class_name .= ' ' . $block['className'];
} ?>

<section <?= esc_attr( $anchor ); ?>class="py-4 <?php echo esc_attr( $class_name ); ?>">
    <div class="container p-0">
        <div class="row">
            <?php if( !empty($title)) { ?>
            <h2><?php echo $title; ?></h2>
            <?php } ?>
            <div class="col">
                <?php if( !empty($logo) ) { ?>
                <img src="<?php echo wp_get_attachment_image_url( $logo, 'full' ); ?>" class="logo" alt="<?php echo $uni; ?>">
                <?php } if( !empty($description) ) { ?>
                <div class="description animate" data-animate="fadeInUp" data-duration="1s" data-delay=".3s" ><?php echo $description; ?></div>
                <?php }  ?>
            </div>
        </div>
    </div>
</section>
