<?php
/**
 * Block template file: template.php
 *
 * Diploma Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

$diploma_title = get_field( 'block_diploma_title' );
$diploma_ids = get_field( 'block_diploma_gallery' );
$diploma_description = get_field( 'block_diploma_description' );

 $anchor = '';
 if ( ! empty( $block['anchor'] ) ) {
     $anchor = 'id=' . esc_attr( $block['anchor'] ) . ' ';
 }
 

$class_name = 'modelo-diploma';
if ( ! empty( $block['className'] ) ) {
    $class_name .= ' ' . $block['className'];
} ?>



<section <?php echo esc_attr( $anchor ); ?>class="py-4 <?php echo esc_attr( $class_name ); ?>">
    <div class="container p-0">
        <div class="row">
            <div class="col">
            <?php if( !empty($diploma_title) ) { ?>
            <h2><?php echo $diploma_title; ?></h2>
            <?php } if( !empty($diploma_ids) ) { ?>
            <div class="d-flex flex-wrap gap-2 justify-content-center pb-4">
                <?php foreach ( $diploma_ids as $item ): ?>
                <a href="<?php echo wp_get_attachment_image_url( $item, 'full' ); ?>">
                    <img src="<?php echo wp_get_attachment_image_url( $item, 'medium' ); ?>" alt="" class="img-fluid">    
                </a>
                <?php endforeach; ?>
            </div>
            <?php } if( !empty($diploma_description) ) { ?>
            <div class="description animate" data-animate="fadeInUp" data-duration="1s" data-delay=".3s" ><?php echo $diploma_description; ?></div>
            <?php }  ?>
            </div>
        </div>
    </div>
</section>