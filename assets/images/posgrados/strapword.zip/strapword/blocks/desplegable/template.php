<?php
/**
 * Block template file: template.php
 *
 * Desplegable Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

$block_title = get_field('block_desplegable_title');
$accordion_left = [];
$count_left = 0;
 if ( have_rows( 'block_desplegable_content_left' ) ) {
     while ( have_rows( 'block_desplegable_content_left' ) ) {
         the_row(); 
         $accordion_left[] = [
             'title' => get_sub_field( 'title' ),
             'text' => get_sub_field( 'description' ),
         ];
     }
 }
 
 $accordion_right = [];
$count_right = 0;
 if ( have_rows( 'block_desplegable_content_right' ) ) {
     while ( have_rows( 'block_desplegable_content_right' ) ) {
         the_row(); 
         $accordion_right[] = [
             'title' => get_sub_field( 'title' ),
             'text' => get_sub_field( 'description' ),
         ];
     }
 }

 $anchor = '';
 if ( ! empty( $block['anchor'] ) ) {
     $anchor = 'id=' . esc_attr( $block['anchor'] ) . ' ';
 }
 

$class_name = 'desplegable';
if ( ! empty( $block['className'] ) ) {
    $class_name .= ' ' . $block['className'];
} ?>

<section <?= esc_attr( $anchor ); ?>class="py-4 <?php echo esc_attr( $class_name ); ?>">
    <div class="container p-0">
        <div class="row">
            <div class="col">
            <?php if( !empty($block_title)) { ?>
            <h2><?php echo $block_title; ?></h2>
            <?php } if ( !empty($accordion_left) || !empty($accordion_right) ) { ?>
            <div class="row">
                <?php if ( !empty($accordion_left) ) { ?>
                <div class="col">
                <div class="accordion accordion-flush" id="accordion_left">
                <?php foreach( $accordion_left as $item ) { ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-left-<?php echo $count_left; ?>" aria-expanded="false" aria-controls="flush-collapse-left-<?php echo $count_left; ?>">
                            <?php echo $item['title']; ?>
                            </button>
                            </h2>
                            <div id="flush-collapse-left-<?php echo $count_left; ?>" class="accordion-collapse collapse" data-bs-parent="#accordion_left">
                            <div class="accordion-body"><?php echo $item['text']; ?></div>
                            </div>
                        </div>
                    <?php 
                    $count_left++;
                    } ?>
                    </div>
                </div>
                <?php } ?>
                <?php if ( !empty($accordion_right) ) { ?>
                <div class="col">
                <div class="accordion accordion-flush" id="accordion_right">
                <?php foreach( $accordion_right as $item ) { ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-right-<?php echo $count_right; ?>" aria-expanded="false" aria-controls="flush-collapse-right-<?php echo $count_right; ?>">
                            <?php echo $item['title']; ?>
                            </button>
                            </h2>
                            <div id="flush-collapse-right-<?php echo $count_right; ?>" class="accordion-collapse collapse" data-bs-parent="#accordion_right">
                            <div class="accordion-body"><?php echo $item['text']; ?></div>
                            </div>
                        </div>
                    <?php 
                    $count_right++;
                    } ?>
                    </div>
                </div>
                <?php } ?>
            </div>
            <?php } ?>

            </div>
        </div>
    </div>
</section>