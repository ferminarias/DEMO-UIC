<?php
/**
 * Block template file: template.php
 *
 * Contenido Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

 $block_title = get_field('block_contenido_title');
 $block_description = get_field('block_contenido_description');
 $block_url = get_field( 'block_contenido_url' );

 $anchor = '';
 if ( ! empty( $block['anchor'] ) ) {
     $anchor = 'id=' . esc_attr( $block['anchor'] ) . ' ';
 }
 

$class_name = 'contenido';
if ( ! empty( $block['className'] ) ) {
    $class_name .= ' ' . $block['className'];
} ?>

<section <?= esc_attr( $anchor ); ?>class="py-4 <?php echo esc_attr( $class_name ); ?>">
    <div class="container">
        <div class="row">
            <div class="col">
            <?php if( !empty($block_title)) { ?>
            <h2 class="animate" data-animate="fadeInUp" data-duration="1s" data-delay=".3s" ><?php echo $block_title; ?></h2>
            <?php } if( !empty($block_description) ) { ?>
            <div class="description animate" data-animate="fadeIn" data-duration="1s" data-delay=".3s" ><?php echo $block_description; ?></div>
            <?php } if( !empty($block_url) ) { ?>
            <div class="btn-container">
                <a href="<?php echo esc_url( $block_url['url'] ); ?>" class="btn btn-secondary" target="<?php echo esc_attr( $block_url['target'] ); ?>"><?php echo esc_html( $block_url['title'] ); ?></a>
            </div>
            <?php }  ?>

            </div>
        </div>
    </div>
</section>
