<?php
/**
 * Author Info block (parent).
 *
 * @param array  $block The block settings and attributes.
 * @param string $content The block inner HTML (empty).
 * @param bool   $is_preview True during backend preview render.
 * @param int    $post_id The post ID the block is rendering content against.
 *                     This is either the post ID currently being displayed inside a query loop,
 *                     or the post ID of the post hosting this block.
 * @param array $context The context provided to the block by the post or it's parent block.
 */

// Support custom id values.
$block_id = '';
if ( ! empty( $block['anchor'] ) ) {
	$block_id = esc_attr( $block['anchor'] );
}

// Create class attribute allowing for custom "className".
$class_name = 'main-container';
if ( ! empty( $block['className'] ) ) {
	$class_name .= ' ' . $block['className'];
}

/**
 * A template string of blocks.
 * Need help converting block HTML markup to an array?
 * 👉 https://happyprime.github.io/wphtml-converter/
 *
 * @link https://developer.wordpress.org/block-editor/reference-guides/block-api/block-templates/
 */
$inner_blocks_template = array(
    array(
        'core/columns',
        array(
            'verticalAlignment' => null,
            'style' => array(
                'color' => array(
                    'background' => '#f0f0f0'
                )
            ),
        ),
        array(
            array(
                'core/column',
                array(
                    'width' => '75%',
                    'className' => 'content',
                    'backgroundColor' => 'white',
                    'lock' => array(
                        'move' => true,
                        'remove' => true
                    )
                ),
                array()
            ),
            array(
                'core/column',
                array(
                    'verticalAlignment' => 'top',
                    'width' => '25%',
                    'className' => 'sidebar sticky-md-top',
                    'lock' => array(
                        'move' => true,
                        'remove' => true
				    )

                ),
                array()
            ),
            
        )
    ),
    
);

?>

<?php if ( ! $is_preview ) { ?>
	<section 
		<?php
		echo wp_kses_data(
			get_block_wrapper_attributes(
				array(
					'id'    => $block_id,
					'class' => esc_attr( $class_name ),
				)
			)
		);
		?>
	>
<?php } ?>

	<InnerBlocks
		class="main-container__innerblocks"
		template="<?php echo esc_attr( wp_json_encode( $inner_blocks_template ) ); ?>"
	/>

<?php if ( ! $is_preview ) { ?>
	</section>
<?php } ?>
