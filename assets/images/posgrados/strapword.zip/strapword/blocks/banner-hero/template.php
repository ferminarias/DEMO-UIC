<?php
/**
 * Block template file: template.php
 *
 * Acreditación Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */


 $anchor = '';
 if ( ! empty( $block['anchor'] ) ) {
     $anchor = 'id=' . esc_attr( $block['anchor'] ) . ' ';
 }
 

$class_name = '';
if ( ! empty( $block['className'] ) ) {
    $class_name .= ' ' . $block['className'];
}
$block_hero_bg = get_field( 'block_hero_bg' );

if ( !empty($block_hero_bg) ) { ?>
<style>
    .hero {
        background-image: url('<?php echo esc_url( wp_get_attachment_image_url( $block_hero_bg, 'medium' ) ); ?>');
    }

    @media screen and (min-width: 768px) {
        .hero {
            background-image: url('<?php echo esc_url( wp_get_attachment_image_url( $block_hero_bg, 'full' ) ); ?>');
        }
    }
</style>
<?php } ?>

<section <?= esc_attr( $anchor ); ?>class="hero <?php echo esc_attr( $class_name ); ?>" >
    <h1 class="animate" data-animate="fadeIn" data-duration="1s" data-delay=".3s" ><?php echo the_title(); ?></h1>
</section>