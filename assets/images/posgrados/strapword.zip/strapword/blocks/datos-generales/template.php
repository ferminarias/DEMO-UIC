<?php
/**
 * Block template file: template.php
 *
 * Acreditación Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */


 $anchor = '';
 if ( ! empty( $block['anchor'] ) ) {
     $anchor = 'id=' . esc_attr( $block['anchor'] ) . ' ';
 }
 

$class_name = 'datos-generales';
if ( ! empty( $block['className'] ) ) {
    $class_name .= ' ' . $block['className'];
}

$datos = [];

if ( have_rows( 'block_datos' ) ) {
    while ( have_rows( 'block_datos' ) ) {
        the_row(); 
        $datos[] = [
            'icon' => get_sub_field( 'block_datos_icon' ),
            'text' => get_sub_field( 'block_datos_text' ),
        ];
    }
}


?>

<section <?php echo esc_attr( $anchor ); ?>class="py-4 <?php echo esc_attr( $class_name ); ?>">

    <div class="container p-0">
        <div class="row">
            <h2 class="animate" data-animate="fadeInUp" data-duration="1s" data-delay=".3s" >Datos generales</h2>
        <?php foreach( $datos as $item ) { ?>
            <div class="col animate" data-animate="fadeIn" data-duration="1s" data-delay=".3s">
                <img src="<?php echo wp_get_attachment_image_url( $item['icon'] ); ?>" alt="">
                <span class="text-center fw-bold" ><?php echo $item['text']; ?></span>
            </div>
        <?php } ?>

        </div>
    </div>

</section>
