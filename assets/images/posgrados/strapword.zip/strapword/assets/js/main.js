/*!
 * strapWord JS
 */

(function ($) {
    'use strict';
    $(document).ready(function () {

        /* =============================== */
        /*              Go Top             */
        /* =============================== */
    
        if (location.hash) {        
            if (location.hash[1] != '.') {
                smoothScrollingTo(location.hash);
            }
        }

        function smoothScrollingTo(target) {
            var navBar = document.getElementById("site-navbar");
            var navBarHeight = 75;

            if (navBar) {
                navBarHeight = navBar.offsetHeight;
            }
            
            $('html,body').animate({ scrollTop: $(target).offset().top - navBarHeight + 2 }, 300);
        }


        $('.menu-item.nav-item > a[href^="#"], a[href^="#"].smooth').on('click', function (event) {
            event.preventDefault();

            smoothScrollingTo(this.hash);

            if (document.querySelector('.offcanvas.show') != null) {
                $('.offcanvas.show .btn-close').click()
            }
        });

        function onScroll(event) {
            
            var scrollPos = $(document).scrollTop();
            var navBar = document.getElementById("site-navbar");
            var navBarHeight = 75;

            if (navBar) {
                navBarHeight = navBar.offsetHeight;
            }
            
            if (scrollPos > 300) {
                $('.go-top').addClass('on');
            } else {
                $('.go-top').removeClass('on');
            }

            $('#site-navbar .menu-item.nav-item:not(.btn-navbar) > a[href^="#"]').each(function () {
                var currLink = $(this);
                var refElement = $(currLink.attr("href"));

                if (refElement.length && (refElement.position().top - navBarHeight + 2 <= scrollPos && refElement.position().top + refElement.height() > scrollPos)) {
                    $('#site-navbar .menu-item.nav-item').removeClass("active");
                    currLink.parent().addClass("active");
                } else {
                    currLink.parent().removeClass("active");
                }
            });
        }
        $(window).on("scroll load resize", onScroll);

        /* =============================== */
        /*           Swiper Init           */
        /* =============================== */
        
        /** Slide Home */
        new Swiper(".swiper-home", { //Change class with class slide
            
            //watchOverflow: true,
            slidesPerView: 1,
            //spaceBetween: 20,

            //autoHeight: true,

            loop: true,
  
            autoplay: {
                delay: 4200,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            pagination: {
                el: ".swiper-pagination",
                clickable: true
            },
            /* breakpoints: {
                // when window width is >= 768px
                768: {
                    slidesPerView: 2,
                    spaceBetween: 20,
                },
                1024: {
                    slidesPerView: 3,
                    spaceBetween: 20,
                },
                1200: {
                    slidesPerView: 4,
                    spaceBetween: 20,
                },
            } */
        });


        /*===============================
        =            Scrolla            =
        ===============================*/
        $('.animate').scrolla({
            once: true // only once animation play on scroll
        });
        
        const grid = $('.items-container');

        grid.on( 'load', function() {
            grid.masonry('layout');
        });


        /* ======================================= */
        /*          View content with Ajax         */
        /* ======================================= */

        $('.card').click(function() {
            var post_id = $(this).attr('id');
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'load_portfolio_data',
                    post_id: post_id
                },
                success: function(response) {
                    const imgUrl = document.querySelector('#img-url-'+ post_id).textContent;
                    var data = JSON.parse(response);
                    $('#portfolioModalLabel').text(data.title);
                    $('#portfolioModalImg').html('<a href="' + imgUrl + '" target="_blank" rel="noopener noreferrer"><img src="' + imgUrl + '" class="img-fluid rounded-4 shadow-sm" alt="' + data.title + '"></a>');
                    $('#portfolioModalDescripcion').html(data.descripcion );
                    $('#portfolioModal').modal('show');
                }
            });
        });

    });
}(jQuery));

