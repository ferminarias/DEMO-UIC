import { swiperTestimonios } from '../functions/swiperInit.js';

document.addEventListener("DOMContentLoaded", () => {

    swiperTestimonios();
    
});
