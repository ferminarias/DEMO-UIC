import { fixedTop } from '../functions/fixed-top.js';
import { scrollaJs } from '../functions/scrolla.js';

document.addEventListener("DOMContentLoaded", () => {

    fixedTop();
    scrollaJs();
});
