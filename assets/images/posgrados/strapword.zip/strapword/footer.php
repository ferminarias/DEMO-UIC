<?php 
    strapword_footer_before();
    require get_template_directory() . '/functions/variables.php';
?>

<footer class="py-5 border-top">
    <div class="container">
        <div class="row row-cols-1 row-cols-md-3 g-2 justify-content-center">
            <div class="col text-center">
            <?php if ( get_field( 'opt_logo_white', 'option' ) ) { ?>
                <img src="<?php the_field( 'opt_logo_white', 'option' ); ?>" class="logo-footer" />
            <?php } ?>
            </div>
        </div>        
    </div>
</footer>

<?php strapword_footer_after();?>

<?php //strapword_bottomline();?>

<?= get_sub_field('opt_whatsapp_on', 'option'); ?>


<?php if ( $whatsappButton ) {

if ( $gotopButton ) { ?>

    <style>
        a.go-top,a.go-top.on {
            right: 22px!important;
        }
        a.go-top.on {
            bottom: 85px!important;
        }
    </style>

<?php } 

if ( $whatsappNumber ) { ?>
    <a class="btn btn-whatsapp" data-animate="bounceIn" data-duration="1.2s" data-delay="4s" title="¡Envianos un WhatsApp!" target="_blank" href="https://wa.me/?phone=<?= $whatsappNumber; ?><?php if ( $whatsappText ) { ?>&text=<?= $whatsappText; ?><?php } ?>"><?php echo load_svg('whatsapp'); ?></a>
<?php }
}
if ( $gotopButton ) { ?>
<a href="#top" class="btn btn-dark go-top px-2 py-1 smooth"  aria-label="Ir arriba" ><i class="bi bi-chevron-up"></i></a>
<?php } ?>

<?php wp_footer(); ?>
</body>
</html>
