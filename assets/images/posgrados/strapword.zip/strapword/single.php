<?php
  get_header();
  strapword_mainbody_before();
  // block-template.php
  if( get_field('block_contacto_id') ) {
    $grid_posts = get_field('block_contacto_id');
  } elseif ( $block['data'] && $block['data']['block_contacto_id'] ) {
    $grid_posts = $block['data']['block_contacto_id'];
  }
?>

<main id="site-main">
  <?php strapword_mainbody_start(); ?>

  <?php get_template_part('loops/single-post', get_post_format()); ?>
  <?= launchpad_render_acf_block('acf/contacto', ['block_contacto_id' => $grid_posts]); ?>

  <?php strapword_mainbody_end(); ?>
</main>

<?php
    strapword_mainbody_after();
    get_footer();
?>
